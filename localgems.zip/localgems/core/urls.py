from django.urls import path
from . import views

urlpatterns = [
    path('home/', views.talent_list, name='talent_list'),
    path('talent/<int:id>/', views.talent_detail, name='talent_detail'),
    path('add-talent/', views.add_talent, name='add_talent'),
    path('register/', views.register, name='register'),
    path('edit-talent/<int:id>/', views.edit_talent, name='edit_talent'),
    path('delete-talent/<int:id>/', views.delete_talent, name='delete_talent'),
]