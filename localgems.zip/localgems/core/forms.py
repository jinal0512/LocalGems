from django import forms
from .models import TalentProfile, User
from django.contrib.auth.forms import UserCreationForm

class TalentProfileForm(forms.ModelForm):
    class Meta:
        model = TalentProfile
        fields = ['name', 'talent_type', 'location', 'description']

class RegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']