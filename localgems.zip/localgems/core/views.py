from django.shortcuts import render, get_object_or_404, redirect
from .models import TalentProfile
from .forms import TalentProfileForm, RegisterForm
from django.contrib.auth.decorators import login_required

# Create your views here.
def talent_list(request):
    talents = TalentProfile.objects.all()
    return render(request, 'talents.html', {'talents': talents})

@login_required
def talent_list(request):
    query = request.GET.get('q')

    if query:
        talents = TalentProfile.objects.filter(name__icontains=query)
    else:
        talents = TalentProfile.objects.all()

    return render(request, 'talents.html', {'talents': talents})

def talent_detail(request, id):
    talent = get_object_or_404(TalentProfile, id=id)
    return render(request, 'talent_detail.html', {'talent': talent})

def add_talent(request):
    if request.method == "POST":
        form = TalentProfileForm(request.POST, request.FILES)
        if form.is_valid():
            talent = form.save(commit=False)
            talent.user = request.user
            talent.save()
            return redirect('talent_list')
    else:
        form = TalentProfileForm()

    return render(request, 'add_talent.html', {'form': form})

def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = RegisterForm()

    return render(request, 'register.html', {'form': form})

@login_required
def edit_talent(request, id):
    talent = get_object_or_404(TalentProfile, id=id)

    if request.method == "POST":
        form = TalentProfileForm(request.POST, request.FILES, instance=talent)
        if form.is_valid():
            form.save()
            return redirect('talent_detail', id=talent.id)
    else:
        form = TalentProfileForm(instance=talent)

    return render(request, 'edit_talent.html', {'form': form})

@login_required
def delete_talent(request, id):
    talent = get_object_or_404(TalentProfile, id=id)
    talent.delete()
    return redirect('talent_list')

